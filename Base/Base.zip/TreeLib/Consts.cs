﻿using _sys.Logging.Structs;

static class Consts
{
	public static class Logging
	{
		public static readonly Sz GutterSz = new(3, 0);
		public const bool AlignLevels = true;
	}
}